export enum CaseTypes {
  Pending = 1,
  Accepted = 2,
  Closed = 3,
  Escalated = 4,
}
